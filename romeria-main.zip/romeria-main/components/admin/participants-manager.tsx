"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Download, CheckCircle, XCircle } from "lucide-react"
import { createBrowserClient } from "@/lib/supabase/client"
import type { Database } from "@/lib/types/database"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

type VisitParticipant = Database["public"]["Tables"]["visit_participants"]["Row"] & {
  profiles?: {
    full_name: string
    email: string
    phone: string
  } | null
}

type SanctuaryVisit = Database["public"]["Tables"]["sanctuary_visits"]["Row"]

interface ParticipantsManagerProps {
  visitId: string
}

export function ParticipantsManager({ visitId }: ParticipantsManagerProps) {
  const [visit, setVisit] = useState<SanctuaryVisit | null>(null)
  const [participants, setParticipants] = useState<VisitParticipant[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const supabase = createBrowserClient()

  useEffect(() => {
    async function fetchData() {
      setIsLoading(true)

      const { data: visitData } = await supabase.from("sanctuary_visits").select("*").eq("id", visitId).single()

      const { data: participantsData } = await supabase
        .from("visit_participants")
        .select("*, profiles(full_name, email, phone)")
        .eq("visit_id", visitId)
        .order("created_at", { ascending: false })

      if (visitData) setVisit(visitData)
      if (participantsData) setParticipants(participantsData as VisitParticipant[])
      setIsLoading(false)
    }

    fetchData()
  }, [visitId])

  async function handleStatusChange(participantId: string, newStatus: "confirmed" | "cancelled") {
    await supabase.from("visit_participants").update({ status: newStatus }).eq("id", participantId)

    setParticipants((prev) => prev.map((p) => (p.id === participantId ? { ...p, status: newStatus } : p)))
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Cargando participantes...</p>
      </div>
    )
  }

  if (!visit) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Alert variant="destructive">
          <AlertDescription>No se encontró la subida</AlertDescription>
        </Alert>
      </div>
    )
  }

  const confirmedCount = participants.filter((p) => p.status === "confirmed").length

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/admin/visits">
                <ArrowLeft className="w-4 h-4" />
              </Link>
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Participantes</h1>
              <p className="text-sm text-muted-foreground">{visit.title}</p>
            </div>
          </div>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Exportar
          </Button>
        </div>
      </header>
      <main className="container mx-auto px-4 py-8">
        <div className="grid gap-4 md:grid-cols-3 mb-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Inscritos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{participants.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Confirmados</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{confirmedCount}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Disponibles</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {visit.max_participants ? visit.max_participants - confirmedCount : "Ilimitado"}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Lista de Participantes</CardTitle>
            <CardDescription>Gestiona las inscripciones a esta subida</CardDescription>
          </CardHeader>
          <CardContent>
            {participants.length === 0 ? (
              <Alert>
                <AlertDescription>No hay participantes inscritos en esta subida</AlertDescription>
              </Alert>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nombre</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Teléfono</TableHead>
                    <TableHead>Notas</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {participants.map((participant) => (
                    <TableRow key={participant.id}>
                      <TableCell className="font-medium">{participant.profiles?.full_name || "N/A"}</TableCell>
                      <TableCell>{participant.profiles?.email || "N/A"}</TableCell>
                      <TableCell>{participant.profiles?.phone || "N/A"}</TableCell>
                      <TableCell className="max-w-xs truncate">{participant.notes || "-"}</TableCell>
                      <TableCell>
                        <Badge variant={participant.status === "confirmed" ? "default" : "secondary"}>
                          {participant.status === "confirmed" ? "Confirmado" : "Cancelado"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {participant.status !== "confirmed" && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleStatusChange(participant.id, "confirmed")}
                            >
                              <CheckCircle className="w-4 h-4 text-primary" />
                            </Button>
                          )}
                          {participant.status !== "cancelled" && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleStatusChange(participant.id, "cancelled")}
                            >
                              <XCircle className="w-4 h-4 text-destructive" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
