"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Plus } from "lucide-react"
import { createBrowserClient } from "@/lib/supabase/client"
import type { Database } from "@/lib/types/database"
import { BlogPostEditor } from "./blog-post-editor"
import { BlogPostsList } from "./blog-posts-list"

type BlogPost = Database["public"]["Tables"]["blog_posts"]["Row"]

export function BlogPostsManager() {
  const [posts, setPosts] = useState<BlogPost[]>([])
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null)
  const [isCreating, setIsCreating] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const supabase = createBrowserClient()

  async function fetchPosts() {
    setIsLoading(true)
    const { data } = await supabase.from("blog_posts").select("*").order("created_at", { ascending: false })
    if (data) setPosts(data)
    setIsLoading(false)
  }

  useEffect(() => {
    fetchPosts()
  }, [])

  function handleNew() {
    setSelectedPost(null)
    setIsCreating(true)
  }

  function handleEdit(post: BlogPost) {
    setSelectedPost(post)
    setIsCreating(false)
  }

  function handleClose() {
    setSelectedPost(null)
    setIsCreating(false)
    fetchPosts()
  }

  if (isCreating || selectedPost) {
    return <BlogPostEditor post={selectedPost} onClose={handleClose} />
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Noticias y Blog</CardTitle>
            <CardDescription>Gestiona noticias, eventos y publicaciones del blog</CardDescription>
          </div>
          <Button onClick={handleNew}>
            <Plus className="w-4 h-4 mr-2" />
            Nueva Publicación
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <BlogPostsList posts={posts} isLoading={isLoading} onEdit={handleEdit} onRefresh={fetchPosts} />
      </CardContent>
    </Card>
  )
}
