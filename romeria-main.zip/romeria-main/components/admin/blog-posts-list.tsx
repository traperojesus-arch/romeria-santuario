"use client"

import { Button } from "@/components/ui/button"
import { Edit, Trash2, Eye, EyeOff } from "lucide-react"
import { createBrowserClient } from "@/lib/supabase/client"
import type { Database } from "@/lib/types/database"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Badge } from "@/components/ui/badge"

type BlogPost = Database["public"]["Tables"]["blog_posts"]["Row"]

interface BlogPostsListProps {
  posts: BlogPost[]
  isLoading: boolean
  onEdit: (post: BlogPost) => void
  onRefresh: () => void
}

const categoryLabels: Record<string, string> = {
  news: "Noticia",
  event: "Evento",
  blog: "Blog",
}

export function BlogPostsList({ posts, isLoading, onEdit, onRefresh }: BlogPostsListProps) {
  const supabase = createBrowserClient()

  async function handleDelete(id: string) {
    await supabase.from("blog_posts").delete().eq("id", id)
    onRefresh()
  }

  async function handleTogglePublish(post: BlogPost) {
    await supabase.from("blog_posts").update({ is_published: !post.is_published }).eq("id", post.id)
    onRefresh()
  }

  if (isLoading) {
    return <p className="text-muted-foreground text-center py-8">Cargando publicaciones...</p>
  }

  if (posts.length === 0) {
    return (
      <Alert>
        <AlertDescription>
          No hay publicaciones creadas. Haz clic en &quot;Nueva Publicación&quot; para comenzar.
        </AlertDescription>
      </Alert>
    )
  }

  return (
    <div className="space-y-3">
      {posts.map((post) => (
        <div key={post.id} className="flex items-center justify-between p-4 border border-border rounded-lg bg-card">
          <div className="flex-1">
            <div className="flex items-center gap-3">
              <h3 className="font-semibold text-foreground">{post.title}</h3>
              <Badge variant="secondary">{categoryLabels[post.category] || post.category}</Badge>
              {post.is_published ? (
                <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">Publicado</span>
              ) : (
                <span className="text-xs bg-muted text-muted-foreground px-2 py-1 rounded">Borrador</span>
              )}
            </div>
            <p className="text-sm text-muted-foreground mt-1">Slug: /{post.slug}</p>
            {post.excerpt && <p className="text-sm text-muted-foreground mt-1 line-clamp-1">{post.excerpt}</p>}
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => handleTogglePublish(post)}>
              {post.is_published ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </Button>
            <Button variant="outline" size="sm" onClick={() => onEdit(post)}>
              <Edit className="w-4 h-4" />
            </Button>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <Trash2 className="w-4 h-4 text-destructive" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>¿Eliminar publicación?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Esta acción no se puede deshacer. La publicación &quot;{post.title}&quot; será eliminada
                    permanentemente.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                  <AlertDialogAction onClick={() => handleDelete(post.id)}>Eliminar</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      ))}
    </div>
  )
}
