"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CMSPagesManager } from "./cms-pages-manager"
import { BlogPostsManager } from "./blog-posts-manager"
import { LogOut, FileText, Newspaper, Mountain } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"
import { createBrowserClient } from "@/lib/supabase/client"
import Link from "next/link"

export function AdminDashboard() {
  const router = useRouter()
  const supabase = createBrowserClient()

  async function handleLogout() {
    await supabase.auth.signOut()
    router.push("/auth/login")
    router.refresh()
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-foreground">Panel de Administración</h1>
          <div className="flex items-center gap-2">
            <Button variant="outline" asChild>
              <Link href="/admin/visits">
                <Mountain className="w-4 h-4 mr-2" />
                Subidas
              </Link>
            </Button>
            <Button variant="outline" onClick={handleLogout}>
              <LogOut className="w-4 h-4 mr-2" />
              Cerrar Sesión
            </Button>
          </div>
        </div>
      </header>
      <main className="container mx-auto px-4 py-8">
        <Tabs defaultValue="pages" className="space-y-6">
          <TabsList className="grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="pages" className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Páginas CMS
            </TabsTrigger>
            <TabsTrigger value="blog" className="flex items-center gap-2">
              <Newspaper className="w-4 h-4" />
              Noticias y Blog
            </TabsTrigger>
          </TabsList>
          <TabsContent value="pages" className="space-y-4">
            <CMSPagesManager />
          </TabsContent>
          <TabsContent value="blog" className="space-y-4">
            <BlogPostsManager />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
