"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Plus } from "lucide-react"
import { createBrowserClient } from "@/lib/supabase/client"
import type { Database } from "@/lib/types/database"
import { CMSPageEditor } from "./cms-page-editor"
import { CMSPagesList } from "./cms-pages-list"

type CMSPage = Database["public"]["Tables"]["cms_pages"]["Row"]

export function CMSPagesManager() {
  const [pages, setPages] = useState<CMSPage[]>([])
  const [selectedPage, setSelectedPage] = useState<CMSPage | null>(null)
  const [isCreating, setIsCreating] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const supabase = createBrowserClient()

  async function fetchPages() {
    setIsLoading(true)
    const { data } = await supabase.from("cms_pages").select("*").order("title")
    if (data) setPages(data)
    setIsLoading(false)
  }

  useEffect(() => {
    fetchPages()
  }, [])

  function handleNew() {
    setSelectedPage(null)
    setIsCreating(true)
  }

  function handleEdit(page: CMSPage) {
    setSelectedPage(page)
    setIsCreating(false)
  }

  function handleClose() {
    setSelectedPage(null)
    setIsCreating(false)
    fetchPages()
  }

  if (isCreating || selectedPage) {
    return <CMSPageEditor page={selectedPage} onClose={handleClose} />
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Páginas CMS</CardTitle>
            <CardDescription>Gestiona páginas estáticas como Historia, Sobre Nosotros, etc.</CardDescription>
          </div>
          <Button onClick={handleNew}>
            <Plus className="w-4 h-4 mr-2" />
            Nueva Página
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <CMSPagesList pages={pages} isLoading={isLoading} onEdit={handleEdit} onRefresh={fetchPages} />
      </CardContent>
    </Card>
  )
}
