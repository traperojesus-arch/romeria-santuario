"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft, Save } from "lucide-react"
import { createBrowserClient } from "@/lib/supabase/client"
import type { Database } from "@/lib/types/database"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type SanctuaryVisit = Database["public"]["Tables"]["sanctuary_visits"]["Row"]

interface VisitEditorProps {
  visit: SanctuaryVisit | null
  onClose: () => void
}

export function VisitEditor({ visit, onClose }: VisitEditorProps) {
  const [title, setTitle] = useState(visit?.title || "")
  const [description, setDescription] = useState(visit?.description || "")
  const [type, setType] = useState<"walking" | "mule" | "horse">(visit?.type || "walking")
  const [visitDate, setVisitDate] = useState(visit?.visit_date?.split("T")[0] || "")
  const [meetingTime, setMeetingTime] = useState(visit?.meeting_time || "")
  const [meetingPoint, setMeetingPoint] = useState(visit?.meeting_point || "")
  const [maxParticipants, setMaxParticipants] = useState(visit?.max_participants?.toString() || "")
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const supabase = createBrowserClient()

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setIsLoading(true)

    try {
      if (visit) {
        const { error: updateError } = await supabase
          .from("sanctuary_visits")
          .update({
            title,
            description,
            type,
            visit_date: visitDate,
            meeting_time: meetingTime || null,
            meeting_point: meetingPoint || null,
            max_participants: maxParticipants ? Number.parseInt(maxParticipants) : null,
          })
          .eq("id", visit.id)

        if (updateError) throw updateError
      } else {
        const { error: insertError } = await supabase.from("sanctuary_visits").insert({
          title,
          description,
          type,
          visit_date: visitDate,
          meeting_time: meetingTime || null,
          meeting_point: meetingPoint || null,
          max_participants: maxParticipants ? Number.parseInt(maxParticipants) : null,
        })

        if (insertError) throw insertError
      }

      setSuccess(true)
      setTimeout(() => onClose(), 1500)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Error al guardar")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <h1 className="text-2xl font-bold text-foreground">{visit ? "Editar Subida" : "Nueva Subida"}</h1>
        </div>
      </header>
      <main className="container mx-auto px-4 py-8">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" onClick={onClose}>
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <div>
                <CardTitle>{visit ? "Editar Subida al Santuario" : "Nueva Subida al Santuario"}</CardTitle>
                <CardDescription>Configura los detalles de la subida</CardDescription>
              </div>
            </div>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-4">
              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              {success && (
                <Alert>
                  <AlertDescription>Subida guardada exitosamente</AlertDescription>
                </Alert>
              )}
              <div className="space-y-2">
                <Label htmlFor="title">Título de la Subida</Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                  disabled={isLoading}
                  placeholder="Ej: Subida al Santuario - Enero 2026"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="type">Tipo de Subida</Label>
                  <Select value={type} onValueChange={(v) => setType(v as typeof type)} disabled={isLoading}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="walking">Andando</SelectItem>
                      <SelectItem value="mule">Mulo</SelectItem>
                      <SelectItem value="horse">Caballo</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="visitDate">Fecha</Label>
                  <Input
                    id="visitDate"
                    type="date"
                    value={visitDate}
                    onChange={(e) => setVisitDate(e.target.value)}
                    required
                    disabled={isLoading}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="meetingTime">Hora de Encuentro</Label>
                  <Input
                    id="meetingTime"
                    type="time"
                    value={meetingTime}
                    onChange={(e) => setMeetingTime(e.target.value)}
                    disabled={isLoading}
                    placeholder="08:00"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="maxParticipants">Máximo de Participantes</Label>
                  <Input
                    id="maxParticipants"
                    type="number"
                    value={maxParticipants}
                    onChange={(e) => setMaxParticipants(e.target.value)}
                    disabled={isLoading}
                    placeholder="Sin límite"
                    min="1"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="meetingPoint">Punto de Encuentro</Label>
                <Input
                  id="meetingPoint"
                  value={meetingPoint}
                  onChange={(e) => setMeetingPoint(e.target.value)}
                  disabled={isLoading}
                  placeholder="Ej: Plaza del Pueblo"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Descripción</Label>
                <Textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  disabled={isLoading}
                  placeholder="Detalles adicionales sobre la subida"
                  rows={4}
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button type="submit" disabled={isLoading} className="w-full">
                <Save className="w-4 h-4 mr-2" />
                {isLoading ? "Guardando..." : "Guardar Subida"}
              </Button>
            </CardFooter>
          </form>
        </Card>
      </main>
    </div>
  )
}
