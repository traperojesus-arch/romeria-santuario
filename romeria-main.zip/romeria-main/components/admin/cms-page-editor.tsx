"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft, Save } from "lucide-react"
import { createBrowserClient } from "@/lib/supabase/client"
import type { Database } from "@/lib/types/database"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import ReactMarkdown from "react-markdown"

type CMSPage = Database["public"]["Tables"]["cms_pages"]["Row"]

interface CMSPageEditorProps {
  page: CMSPage | null
  onClose: () => void
}

export function CMSPageEditor({ page, onClose }: CMSPageEditorProps) {
  const [title, setTitle] = useState(page?.title || "")
  const [slug, setSlug] = useState(page?.slug || "")
  const [content, setContent] = useState(page?.content || "")
  const [metaDescription, setMetaDescription] = useState(page?.meta_description || "")
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const supabase = createBrowserClient()

  useEffect(() => {
    if (!page && title && !slug) {
      const generatedSlug = title
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "")
      setSlug(generatedSlug)
    }
  }, [title, page, slug])

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setIsLoading(true)

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) throw new Error("No autenticado")

      if (page) {
        const { error: updateError } = await supabase
          .from("cms_pages")
          .update({
            title,
            slug,
            content,
            meta_description: metaDescription,
          })
          .eq("id", page.id)

        if (updateError) throw updateError
      } else {
        const { error: insertError } = await supabase.from("cms_pages").insert({
          title,
          slug,
          content,
          meta_description: metaDescription,
          author_id: user.id,
          is_published: false,
        })

        if (insertError) throw insertError
      }

      setSuccess(true)
      setTimeout(() => onClose(), 1500)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Error al guardar")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" onClick={onClose}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <CardTitle>{page ? "Editar Página" : "Nueva Página"}</CardTitle>
            <CardDescription>Usa Markdown para formatear el contenido</CardDescription>
          </div>
        </div>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          {success && (
            <Alert>
              <AlertDescription>Página guardada exitosamente</AlertDescription>
            </Alert>
          )}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="title">Título</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
                disabled={isLoading}
                placeholder="Ej: Historia del Santuario"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="slug">Slug (URL)</Label>
              <Input
                id="slug"
                value={slug}
                onChange={(e) => setSlug(e.target.value)}
                required
                disabled={isLoading}
                placeholder="historia-del-santuario"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="metaDescription">Meta Descripción (SEO)</Label>
            <Input
              id="metaDescription"
              value={metaDescription}
              onChange={(e) => setMetaDescription(e.target.value)}
              disabled={isLoading}
              placeholder="Descripción breve para buscadores"
            />
          </div>
          <div className="space-y-2">
            <Label>Contenido (Markdown)</Label>
            <Tabs defaultValue="edit" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="edit">Editar</TabsTrigger>
                <TabsTrigger value="preview">Vista Previa</TabsTrigger>
              </TabsList>
              <TabsContent value="edit">
                <Textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  required
                  disabled={isLoading}
                  className="min-h-96 font-mono text-sm"
                  placeholder="# Título&#10;&#10;Escribe tu contenido en Markdown..."
                />
              </TabsContent>
              <TabsContent value="preview">
                <div className="min-h-96 p-4 border border-border rounded-md bg-card prose prose-sm max-w-none">
                  <ReactMarkdown>{content}</ReactMarkdown>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" disabled={isLoading} className="w-full">
            <Save className="w-4 h-4 mr-2" />
            {isLoading ? "Guardando..." : "Guardar Página"}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}
