"use client"

import { Button } from "@/components/ui/button"
import { Edit, Trash2, Calendar, Users } from "lucide-react"
import { createBrowserClient } from "@/lib/supabase/client"
import type { Database } from "@/lib/types/database"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Badge } from "@/components/ui/badge"
import { format } from "date-fns"
import { es } from "date-fns/locale"
import Link from "next/link"

type SanctuaryVisit = Database["public"]["Tables"]["sanctuary_visits"]["Row"]

interface VisitsListProps {
  visits: SanctuaryVisit[]
  isLoading: boolean
  onEdit: (visit: SanctuaryVisit) => void
  onRefresh: () => void
}

const typeLabels: Record<string, string> = {
  walking: "Andando",
  mule: "Mulo",
  horse: "Caballo",
}

const typeColors: Record<string, string> = {
  walking: "bg-primary/10 text-primary",
  mule: "bg-secondary/10 text-secondary-foreground",
  horse: "bg-accent text-accent-foreground",
}

export function VisitsList({ visits, isLoading, onEdit, onRefresh }: VisitsListProps) {
  const supabase = createBrowserClient()

  async function handleDelete(id: string) {
    await supabase.from("sanctuary_visits").delete().eq("id", id)
    onRefresh()
  }

  if (isLoading) {
    return <p className="text-muted-foreground text-center py-8">Cargando subidas...</p>
  }

  if (visits.length === 0) {
    return (
      <Alert>
        <AlertDescription>
          No hay subidas programadas. Haz clic en &quot;Nueva Subida&quot; para comenzar.
        </AlertDescription>
      </Alert>
    )
  }

  return (
    <div className="space-y-3">
      {visits.map((visit) => (
        <div key={visit.id} className="flex items-center justify-between p-4 border border-border rounded-lg bg-card">
          <div className="flex-1">
            <div className="flex items-center gap-3">
              <h3 className="font-semibold text-foreground">{visit.title}</h3>
              <Badge className={typeColors[visit.type]}>{typeLabels[visit.type] || visit.type}</Badge>
              {visit.max_participants && (
                <span className="text-xs bg-muted text-muted-foreground px-2 py-1 rounded flex items-center gap-1">
                  <Users className="w-3 h-3" />
                  Max: {visit.max_participants}
                </span>
              )}
            </div>
            <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                {format(new Date(visit.visit_date), "d 'de' MMMM 'de' yyyy", { locale: es })}
              </span>
              {visit.meeting_point && <span>Punto: {visit.meeting_point}</span>}
            </div>
            {visit.description && (
              <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{visit.description}</p>
            )}
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" asChild>
              <Link href={`/admin/visits/${visit.id}/participants`}>
                <Users className="w-4 h-4" />
              </Link>
            </Button>
            <Button variant="outline" size="sm" onClick={() => onEdit(visit)}>
              <Edit className="w-4 h-4" />
            </Button>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <Trash2 className="w-4 h-4 text-destructive" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>¿Eliminar subida?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Esta acción no se puede deshacer. La subida &quot;{visit.title}&quot; será eliminada
                    permanentemente.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                  <AlertDialogAction onClick={() => handleDelete(visit.id)}>Eliminar</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      ))}
    </div>
  )
}
