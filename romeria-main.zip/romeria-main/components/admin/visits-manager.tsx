"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Plus } from "lucide-react"
import { createBrowserClient } from "@/lib/supabase/client"
import type { Database } from "@/lib/types/database"
import { VisitEditor } from "./visit-editor"
import { VisitsList } from "./visits-list"

type SanctuaryVisit = Database["public"]["Tables"]["sanctuary_visits"]["Row"]

export function VisitsManager() {
  const [visits, setVisits] = useState<SanctuaryVisit[]>([])
  const [selectedVisit, setSelectedVisit] = useState<SanctuaryVisit | null>(null)
  const [isCreating, setIsCreating] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const supabase = createBrowserClient()

  async function fetchVisits() {
    setIsLoading(true)
    const { data } = await supabase.from("sanctuary_visits").select("*").order("visit_date", { ascending: true })
    if (data) setVisits(data)
    setIsLoading(false)
  }

  useEffect(() => {
    fetchVisits()
  }, [])

  function handleNew() {
    setSelectedVisit(null)
    setIsCreating(true)
  }

  function handleEdit(visit: SanctuaryVisit) {
    setSelectedVisit(visit)
    setIsCreating(false)
  }

  function handleClose() {
    setSelectedVisit(null)
    setIsCreating(false)
    fetchVisits()
  }

  if (isCreating || selectedVisit) {
    return <VisitEditor visit={selectedVisit} onClose={handleClose} />
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <h1 className="text-2xl font-bold text-foreground">Gestión de Subidas al Santuario</h1>
        </div>
      </header>
      <main className="container mx-auto px-4 py-8">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Subidas al Santuario</CardTitle>
                <CardDescription>Programa las subidas andando, en mulo y en caballo</CardDescription>
              </div>
              <Button onClick={handleNew}>
                <Plus className="w-4 h-4 mr-2" />
                Nueva Subida
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <VisitsList visits={visits} isLoading={isLoading} onEdit={handleEdit} onRefresh={fetchVisits} />
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
