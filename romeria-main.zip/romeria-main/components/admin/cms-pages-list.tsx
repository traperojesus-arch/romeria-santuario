"use client"

import { Button } from "@/components/ui/button"
import { Edit, Trash2, Eye, EyeOff } from "lucide-react"
import { createBrowserClient } from "@/lib/supabase/client"
import type { Database } from "@/lib/types/database"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

type CMSPage = Database["public"]["Tables"]["cms_pages"]["Row"]

interface CMSPagesListProps {
  pages: CMSPage[]
  isLoading: boolean
  onEdit: (page: CMSPage) => void
  onRefresh: () => void
}

export function CMSPagesList({ pages, isLoading, onEdit, onRefresh }: CMSPagesListProps) {
  const supabase = createBrowserClient()

  async function handleDelete(id: string) {
    await supabase.from("cms_pages").delete().eq("id", id)
    onRefresh()
  }

  async function handleTogglePublish(page: CMSPage) {
    await supabase.from("cms_pages").update({ is_published: !page.is_published }).eq("id", page.id)
    onRefresh()
  }

  if (isLoading) {
    return <p className="text-muted-foreground text-center py-8">Cargando páginas...</p>
  }

  if (pages.length === 0) {
    return (
      <Alert>
        <AlertDescription>No hay páginas creadas. Haz clic en &quot;Nueva Página&quot; para comenzar.</AlertDescription>
      </Alert>
    )
  }

  return (
    <div className="space-y-3">
      {pages.map((page) => (
        <div key={page.id} className="flex items-center justify-between p-4 border border-border rounded-lg bg-card">
          <div className="flex-1">
            <div className="flex items-center gap-3">
              <h3 className="font-semibold text-foreground">{page.title}</h3>
              {page.is_published ? (
                <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">Publicado</span>
              ) : (
                <span className="text-xs bg-muted text-muted-foreground px-2 py-1 rounded">Borrador</span>
              )}
            </div>
            <p className="text-sm text-muted-foreground mt-1">Slug: /{page.slug}</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => handleTogglePublish(page)}>
              {page.is_published ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </Button>
            <Button variant="outline" size="sm" onClick={() => onEdit(page)}>
              <Edit className="w-4 h-4" />
            </Button>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <Trash2 className="w-4 h-4 text-destructive" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>¿Eliminar página?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Esta acción no se puede deshacer. La página &quot;{page.title}&quot; será eliminada permanentemente.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                  <AlertDialogAction onClick={() => handleDelete(page.id)}>Eliminar</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      ))}
    </div>
  )
}
