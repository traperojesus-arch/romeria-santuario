"use client"

import { CarretistaDashboard } from "@/components/carretista/carretista-dashboard"
import type { Database } from "@/lib/types/database"

type Profile = Database["public"]["Tables"]["profiles"]["Row"]

interface CaballistaDashboardProps {
  profile: Profile
}

export function CaballistaDashboard({ profile }: CaballistaDashboardProps) {
  return <CarretistaDashboard profile={profile} />
}
