"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowLeft, Plus, Edit, Trash2, Save } from "lucide-react"
import { createBrowserClient } from "@/lib/supabase/client"
import type { Database } from "@/lib/types/database"
import Link from "next/link"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

type Profile = Database["public"]["Tables"]["profiles"]["Row"]
type SavedParticipant = Database["public"]["Tables"]["saved_participants"]["Row"]

interface ParticipantsLibraryProps {
  profile: Profile
}

export function ParticipantsLibrary({ profile }: ParticipantsLibraryProps) {
  const [participants, setParticipants] = useState<SavedParticipant[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isEditing, setIsEditing] = useState<string | null>(null)
  const [editForm, setEditForm] = useState({
    full_name: "",
    dni: "",
    phone: "",
    email: "",
  })
  const supabase = createBrowserClient()

  useEffect(() => {
    fetchParticipants()
  }, [profile.id])

  async function fetchParticipants() {
    setIsLoading(true)
    const { data } = await supabase.from("saved_participants").select("*").eq("user_id", profile.id).order("full_name")

    if (data) setParticipants(data)
    setIsLoading(false)
  }

  async function handleSave() {
    if (isEditing) {
      await supabase.from("saved_participants").update(editForm).eq("id", isEditing)
    } else {
      await supabase.from("saved_participants").insert({
        ...editForm,
        user_id: profile.id,
      })
    }
    setIsEditing(null)
    setEditForm({ full_name: "", dni: "", phone: "", email: "" })
    fetchParticipants()
  }

  async function handleDelete(id: string) {
    await supabase.from("saved_participants").delete().eq("id", id)
    fetchParticipants()
  }

  function handleEdit(participant: SavedParticipant) {
    setIsEditing(participant.id)
    setEditForm({
      full_name: participant.full_name,
      dni: participant.dni,
      phone: participant.phone || "",
      email: participant.email || "",
    })
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center gap-4">
          <Button variant="ghost" size="sm" asChild>
            <Link href={`/${profile.role}/dashboard`}>
              <ArrowLeft className="w-4 h-4" />
            </Link>
          </Button>
          <h1 className="text-2xl font-bold text-foreground">Mis Participantes Guardados</h1>
        </div>
      </header>
      <main className="container mx-auto px-4 py-8">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Biblioteca de Participantes</CardTitle>
                <CardDescription>
                  Guarda los datos de participantes para reutilizarlos en futuras solicitudes
                </CardDescription>
              </div>
              <Dialog open={isEditing !== null && !participants.find((p) => p.id === isEditing)}>
                <DialogTrigger asChild>
                  <Button
                    onClick={() => {
                      setIsEditing("new")
                      setEditForm({ full_name: "", dni: "", phone: "", email: "" })
                    }}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Añadir Participante
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>{isEditing === "new" ? "Nuevo Participante" : "Editar Participante"}</DialogTitle>
                    <DialogDescription>Guarda los datos para reutilizar en permisos futuros</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="full_name">Nombre Completo</Label>
                      <Input
                        id="full_name"
                        value={editForm.full_name}
                        onChange={(e) => setEditForm({ ...editForm, full_name: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="dni">DNI</Label>
                      <Input
                        id="dni"
                        value={editForm.dni}
                        onChange={(e) => setEditForm({ ...editForm, dni: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Teléfono</Label>
                      <Input
                        id="phone"
                        value={editForm.phone}
                        onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={editForm.email}
                        onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button
                      variant="outline"
                      onClick={() => {
                        setIsEditing(null)
                        setEditForm({ full_name: "", dni: "", phone: "", email: "" })
                      }}
                    >
                      Cancelar
                    </Button>
                    <Button onClick={handleSave}>
                      <Save className="w-4 h-4 mr-2" />
                      Guardar
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <p className="text-muted-foreground text-center py-8">Cargando participantes...</p>
            ) : participants.length === 0 ? (
              <Alert>
                <AlertDescription>
                  No tienes participantes guardados. Añade participantes para reutilizar sus datos en solicitudes de
                  permisos.
                </AlertDescription>
              </Alert>
            ) : (
              <div className="space-y-3">
                {participants.map((participant) => (
                  <div
                    key={participant.id}
                    className="flex items-center justify-between p-4 border border-border rounded-lg"
                  >
                    <div className="flex-1">
                      <h3 className="font-semibold">{participant.full_name}</h3>
                      <div className="text-sm text-muted-foreground mt-1 space-y-1">
                        <p>DNI: {participant.dni}</p>
                        {participant.phone && <p>Teléfono: {participant.phone}</p>}
                        {participant.email && <p>Email: {participant.email}</p>}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          handleEdit(participant)
                        }}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleDelete(participant.id)}>
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>

      {isEditing && participants.find((p) => p.id === isEditing) && (
        <Dialog
          open
          onOpenChange={() => {
            setIsEditing(null)
            setEditForm({ full_name: "", dni: "", phone: "", email: "" })
          }}
        >
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Editar Participante</DialogTitle>
              <DialogDescription>Actualiza los datos del participante</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit_full_name">Nombre Completo</Label>
                <Input
                  id="edit_full_name"
                  value={editForm.full_name}
                  onChange={(e) => setEditForm({ ...editForm, full_name: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit_dni">DNI</Label>
                <Input
                  id="edit_dni"
                  value={editForm.dni}
                  onChange={(e) => setEditForm({ ...editForm, dni: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit_phone">Teléfono</Label>
                <Input
                  id="edit_phone"
                  value={editForm.phone}
                  onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit_email">Email</Label>
                <Input
                  id="edit_email"
                  type="email"
                  value={editForm.email}
                  onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => {
                  setIsEditing(null)
                  setEditForm({ full_name: "", dni: "", phone: "", email: "" })
                }}
              >
                Cancelar
              </Button>
              <Button onClick={handleSave}>
                <Save className="w-4 h-4 mr-2" />
                Guardar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}
