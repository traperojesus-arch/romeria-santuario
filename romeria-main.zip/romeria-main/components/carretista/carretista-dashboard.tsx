"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { LogOut, FileText, Plus, Users, Download } from "lucide-react"
import { createBrowserClient } from "@/lib/supabase/client"
import type { Database } from "@/lib/types/database"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { format } from "date-fns"
import { es } from "date-fns/locale"

type Profile = Database["public"]["Tables"]["profiles"]["Row"]
type RomeriaPermit = Database["public"]["Tables"]["romeria_permits"]["Row"]

interface CarretistaDashboardProps {
  profile: Profile
}

export function CarretistaDashboard({ profile }: CarretistaDashboardProps) {
  const [permits, setPermits] = useState<RomeriaPermit[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const supabase = createBrowserClient()

  useEffect(() => {
    async function fetchPermits() {
      setIsLoading(true)
      const { data } = await supabase
        .from("romeria_permits")
        .select("*")
        .eq("user_id", profile.id)
        .order("created_at", { ascending: false })

      if (data) setPermits(data)
      setIsLoading(false)
    }

    fetchPermits()
  }, [profile.id])

  async function handleLogout() {
    await supabase.auth.signOut()
    router.push("/auth/login")
    router.refresh()
  }

  function handleDownloadPDF(permitId: string) {
    window.open(`/api/permits/${permitId}/pdf`, "_blank")
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-foreground">
            Panel de {profile.role === "carretista" ? "Carretista" : "Caballista"}
          </h1>
          <div className="flex items-center gap-2">
            <Button variant="outline" asChild>
              <Link href={`/${profile.role}/participants`}>
                <Users className="w-4 h-4 mr-2" />
                Mis Participantes
              </Link>
            </Button>
            <Button variant="outline" onClick={handleLogout}>
              <LogOut className="w-4 h-4 mr-2" />
              Cerrar Sesión
            </Button>
          </div>
        </div>
      </header>
      <main className="container mx-auto px-4 py-8">
        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Bienvenido, {profile.full_name}</CardTitle>
              <CardDescription>Gestiona tus permisos y participantes para la romería</CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Mis Solicitudes de Permisos</CardTitle>
                  <CardDescription>Permisos para subir a la romería</CardDescription>
                </div>
                <Button asChild>
                  <Link href={`/${profile.role}/permits/new`}>
                    <Plus className="w-4 h-4 mr-2" />
                    Nueva Solicitud
                  </Link>
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <p className="text-muted-foreground text-center py-8">Cargando solicitudes...</p>
              ) : permits.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-muted-foreground mb-4">No tienes solicitudes de permisos</p>
                  <Button asChild>
                    <Link href={`/${profile.role}/permits/new`}>
                      <Plus className="w-4 h-4 mr-2" />
                      Crear Primera Solicitud
                    </Link>
                  </Button>
                </div>
              ) : (
                <div className="space-y-3">
                  {permits.map((permit) => (
                    <div
                      key={permit.id}
                      className="flex items-center justify-between p-4 border border-border rounded-lg"
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-3">
                          <h3 className="font-semibold">Permiso Romería {permit.year}</h3>
                          <Badge
                            variant={
                              permit.status === "approved"
                                ? "default"
                                : permit.status === "pending"
                                  ? "secondary"
                                  : "destructive"
                            }
                          >
                            {permit.status === "approved"
                              ? "Aprobado"
                              : permit.status === "pending"
                                ? "Pendiente"
                                : "Rechazado"}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                          Creado: {format(new Date(permit.created_at), "d 'de' MMMM 'de' yyyy", { locale: es })}
                        </p>
                        {permit.notes && <p className="text-sm text-muted-foreground mt-1">{permit.notes}</p>}
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="outline" size="sm" onClick={() => handleDownloadPDF(permit.id)}>
                          <Download className="w-4 h-4 mr-2" />
                          Descargar PDF
                        </Button>
                        <Button variant="outline" size="sm" asChild>
                          <Link href={`/${profile.role}/permits/${permit.id}`}>
                            <FileText className="w-4 h-4" />
                          </Link>
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
