"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, Plus, Trash2, FileText } from "lucide-react"
import { createBrowserClient } from "@/lib/supabase/client"
import type { Database } from "@/lib/types/database"
import Link from "next/link"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Checkbox } from "@/components/ui/checkbox"
import { useRouter } from "next/navigation"

type Profile = Database["public"]["Tables"]["profiles"]["Row"]
type SavedParticipant = Database["public"]["Tables"]["saved_participants"]["Row"]
type Vehicle = Database["public"]["Tables"]["vehicles"]["Row"]

interface PermitFormProps {
  profile: Profile
}

interface PermitParticipant {
  full_name: string
  dni: string
  phone: string
  email: string
  saved_participant_id?: string
}

export function PermitForm({ profile }: PermitFormProps) {
  const [year, setYear] = useState(new Date().getFullYear())
  const [notes, setNotes] = useState("")
  const [selectedParticipants, setSelectedParticipants] = useState<PermitParticipant[]>([])
  const [savedParticipants, setSavedParticipants] = useState<SavedParticipant[]>([])
  const [vehicles, setVehicles] = useState<Vehicle[]>([])
  const [selectedVehicleId, setSelectedVehicleId] = useState<string>("")
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const supabase = createBrowserClient()
  const router = useRouter()

  useEffect(() => {
    async function fetchData() {
      const { data: participantsData } = await supabase
        .from("saved_participants")
        .select("*")
        .eq("user_id", profile.id)
        .order("full_name")

      const { data: vehiclesData } = await supabase.from("vehicles").select("*").eq("owner_id", profile.id)

      if (participantsData) setSavedParticipants(participantsData)
      if (vehiclesData) setVehicles(vehiclesData)
    }

    fetchData()
  }, [profile.id])

  function toggleParticipant(participant: SavedParticipant) {
    const exists = selectedParticipants.find((p) => p.saved_participant_id === participant.id)
    if (exists) {
      setSelectedParticipants(selectedParticipants.filter((p) => p.saved_participant_id !== participant.id))
    } else {
      setSelectedParticipants([
        ...selectedParticipants,
        {
          full_name: participant.full_name,
          dni: participant.dni,
          phone: participant.phone || "",
          email: participant.email || "",
          saved_participant_id: participant.id,
        },
      ])
    }
  }

  function addNewParticipant() {
    setSelectedParticipants([
      ...selectedParticipants,
      {
        full_name: "",
        dni: "",
        phone: "",
        email: "",
      },
    ])
  }

  function removeParticipant(index: number) {
    setSelectedParticipants(selectedParticipants.filter((_, i) => i !== index))
  }

  function updateParticipant(index: number, field: keyof PermitParticipant, value: string) {
    const updated = [...selectedParticipants]
    updated[index] = { ...updated[index], [field]: value }
    setSelectedParticipants(updated)
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setIsLoading(true)

    try {
      if (selectedParticipants.length === 0) {
        throw new Error("Debes añadir al menos un participante")
      }

      if (!selectedVehicleId) {
        throw new Error("Debes seleccionar un vehículo")
      }

      // Create permit
      const { data: permit, error: permitError } = await supabase
        .from("romeria_permits")
        .insert({
          user_id: profile.id,
          year,
          status: "pending",
          notes: notes || null,
          vehicle_id: selectedVehicleId,
        })
        .select()
        .single()

      if (permitError) throw permitError

      // Add participants to permit
      const participantsToInsert = selectedParticipants.map((p) => ({
        permit_id: permit.id,
        full_name: p.full_name,
        dni: p.dni,
        phone: p.phone || null,
        email: p.email || null,
      }))

      const { error: participantsError } = await supabase.from("permit_participants").insert(participantsToInsert)

      if (participantsError) throw participantsError

      router.push("/carretista/dashboard")
    } catch (err) {
      setError(err instanceof Error ? err.message : "Error al crear la solicitud")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center gap-4">
          <Button variant="ghost" size="sm" asChild>
            <Link href="/carretista/dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Link>
          </Button>
          <h1 className="text-2xl font-bold text-foreground">Nueva Solicitud de Permiso</h1>
        </div>
      </header>
      <main className="container mx-auto px-4 py-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <Card>
            <CardHeader>
              <CardTitle>Información General</CardTitle>
              <CardDescription>Detalles básicos de la solicitud</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="year">Año</Label>
                  <Input id="year" type="number" value={year} onChange={(e) => setYear(Number(e.target.value))} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="vehicle">Vehículo</Label>
                  <select
                    id="vehicle"
                    value={selectedVehicleId}
                    onChange={(e) => setSelectedVehicleId(e.target.value)}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                    required
                  >
                    <option value="">Selecciona un vehículo</option>
                    {vehicles.map((vehicle) => (
                      <option key={vehicle.id} value={vehicle.id}>
                        {vehicle.license_plate} - {vehicle.brand} {vehicle.model}
                      </option>
                    ))}
                  </select>
                  {vehicles.length === 0 && (
                    <p className="text-sm text-muted-foreground">
                      No tienes vehículos registrados.{" "}
                      <Link href="/carretista/vehicles" className="text-primary underline">
                        Añade uno aquí
                      </Link>
                    </p>
                  )}
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="notes">Notas</Label>
                <Textarea
                  id="notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Información adicional"
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Participantes</CardTitle>
              <CardDescription>Selecciona participantes guardados o añade nuevos</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {savedParticipants.length > 0 && (
                <div className="space-y-2">
                  <Label>Seleccionar de Participantes Guardados</Label>
                  <div className="grid grid-cols-2 gap-3 p-4 border border-border rounded-lg">
                    {savedParticipants.map((participant) => (
                      <div key={participant.id} className="flex items-center gap-2">
                        <Checkbox
                          id={participant.id}
                          checked={selectedParticipants.some((p) => p.saved_participant_id === participant.id)}
                          onCheckedChange={() => toggleParticipant(participant)}
                        />
                        <Label htmlFor={participant.id} className="cursor-pointer">
                          {participant.full_name} ({participant.dni})
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="space-y-3">
                {selectedParticipants.map((participant, index) => (
                  <div key={index} className="p-4 border border-border rounded-lg space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-semibold">Participante {index + 1}</h4>
                      <Button type="button" variant="ghost" size="sm" onClick={() => removeParticipant(index)}>
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                    {!participant.saved_participant_id && (
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-2">
                          <Label>Nombre Completo</Label>
                          <Input
                            value={participant.full_name}
                            onChange={(e) => updateParticipant(index, "full_name", e.target.value)}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>DNI</Label>
                          <Input
                            value={participant.dni}
                            onChange={(e) => updateParticipant(index, "dni", e.target.value)}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Teléfono</Label>
                          <Input
                            value={participant.phone}
                            onChange={(e) => updateParticipant(index, "phone", e.target.value)}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Email</Label>
                          <Input
                            type="email"
                            value={participant.email}
                            onChange={(e) => updateParticipant(index, "email", e.target.value)}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              <Button type="button" variant="outline" onClick={addNewParticipant} className="w-full bg-transparent">
                <Plus className="w-4 h-4 mr-2" />
                Añadir Nuevo Participante
              </Button>
            </CardContent>
          </Card>

          <div className="flex gap-4">
            <Button type="button" variant="outline" asChild className="flex-1 bg-transparent">
              <Link href="/carretista/dashboard">Cancelar</Link>
            </Button>
            <Button type="submit" disabled={isLoading} className="flex-1">
              <FileText className="w-4 h-4 mr-2" />
              {isLoading ? "Creando..." : "Crear Solicitud"}
            </Button>
          </div>
        </form>
      </main>
    </div>
  )
}
