"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, MapPin, Users, UserPlus } from "lucide-react"
import { createBrowserClient } from "@/lib/supabase/client"
import type { Database } from "@/lib/types/database"
import { format } from "date-fns"
import { es } from "date-fns/locale"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { VisitRegistrationDialog } from "./visit-registration-dialog"
import { useRouter } from "next/navigation"

type SanctuaryVisit = Database["public"]["Tables"]["sanctuary_visits"]["Row"]

const typeLabels: Record<string, string> = {
  walking: "Andando",
  mule: "Mulo",
  horse: "Caballo",
}

const typeColors: Record<string, string> = {
  walking: "bg-primary/10 text-primary",
  mule: "bg-secondary/10 text-secondary-foreground",
  horse: "bg-accent text-accent-foreground",
}

export function PublicVisitsCalendar() {
  const [visits, setVisits] = useState<SanctuaryVisit[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [selectedType, setSelectedType] = useState<string>("all")
  const [selectedVisit, setSelectedVisit] = useState<SanctuaryVisit | null>(null)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const supabase = createBrowserClient()
  const router = useRouter()

  useEffect(() => {
    async function checkAuth() {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      setIsAuthenticated(!!user)
    }
    checkAuth()
  }, [])

  useEffect(() => {
    async function fetchVisits() {
      setIsLoading(true)
      const today = new Date().toISOString().split("T")[0]
      const { data } = await supabase
        .from("sanctuary_visits")
        .select("*")
        .gte("visit_date", today)
        .order("visit_date", { ascending: true })

      if (data) setVisits(data)
      setIsLoading(false)
    }

    fetchVisits()
  }, [])

  function handleRegister(visit: SanctuaryVisit) {
    if (!isAuthenticated) {
      router.push("/auth/login")
      return
    }
    setSelectedVisit(visit)
  }

  const filteredVisits = selectedType === "all" ? visits : visits.filter((v) => v.type === selectedType)

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Subidas al Santuario</h1>
          <p className="text-muted-foreground">Consulta las próximas subidas programadas y apúntate</p>
        </div>
      </header>
      <main className="container mx-auto px-4 py-8">
        <Tabs value={selectedType} onValueChange={setSelectedType} className="space-y-6">
          <TabsList className="grid w-full max-w-lg grid-cols-4">
            <TabsTrigger value="all">Todas</TabsTrigger>
            <TabsTrigger value="walking">Andando</TabsTrigger>
            <TabsTrigger value="mule">Mulo</TabsTrigger>
            <TabsTrigger value="horse">Caballo</TabsTrigger>
          </TabsList>
          <TabsContent value={selectedType} className="space-y-4">
            {isLoading ? (
              <p className="text-muted-foreground text-center py-8">Cargando subidas...</p>
            ) : filteredVisits.length === 0 ? (
              <Alert>
                <AlertDescription>
                  No hay subidas programadas {selectedType !== "all" && `de tipo ${typeLabels[selectedType]}`} por el
                  momento.
                </AlertDescription>
              </Alert>
            ) : (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {filteredVisits.map((visit) => (
                  <Card key={visit.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <CardTitle className="text-lg">{visit.title}</CardTitle>
                        <Badge className={typeColors[visit.type]}>{typeLabels[visit.type]}</Badge>
                      </div>
                      <CardDescription className="flex items-center gap-1 mt-2">
                        <Calendar className="w-4 h-4" />
                        {format(new Date(visit.visit_date), "d 'de' MMMM 'de' yyyy", { locale: es })}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {visit.meeting_time && (
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Clock className="w-4 h-4" />
                          <span>{visit.meeting_time}</span>
                        </div>
                      )}
                      {visit.meeting_point && (
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <MapPin className="w-4 h-4" />
                          <span>{visit.meeting_point}</span>
                        </div>
                      )}
                      {visit.max_participants && (
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Users className="w-4 h-4" />
                          <span>Máximo: {visit.max_participants} participantes</span>
                        </div>
                      )}
                      {visit.description && (
                        <p className="text-sm text-muted-foreground mt-2 line-clamp-3">{visit.description}</p>
                      )}
                      <Button className="w-full mt-4" onClick={() => handleRegister(visit)}>
                        <UserPlus className="w-4 h-4 mr-2" />
                        Inscribirme
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>
      {selectedVisit && (
        <VisitRegistrationDialog
          visit={selectedVisit}
          onClose={() => setSelectedVisit(null)}
          onSuccess={() => {
            setSelectedVisit(null)
            alert("Inscripción realizada con éxito")
          }}
        />
      )}
    </div>
  )
}
