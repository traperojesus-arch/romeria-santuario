"use client"

import type React from "react"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { createBrowserClient } from "@/lib/supabase/client"
import type { Database } from "@/lib/types/database"

type SanctuaryVisit = Database["public"]["Tables"]["sanctuary_visits"]["Row"]

interface VisitRegistrationDialogProps {
  visit: SanctuaryVisit
  onClose: () => void
  onSuccess: () => void
}

export function VisitRegistrationDialog({ visit, onClose, onSuccess }: VisitRegistrationDialogProps) {
  const [notes, setNotes] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const supabase = createBrowserClient()

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setIsLoading(true)

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        throw new Error("Debes iniciar sesión")
      }

      // Check if already registered
      const { data: existing } = await supabase
        .from("visit_participants")
        .select("id")
        .eq("visit_id", visit.id)
        .eq("user_id", user.id)
        .single()

      if (existing) {
        throw new Error("Ya estás inscrito en esta subida")
      }

      // Check if visit is full
      if (visit.max_participants) {
        const { count } = await supabase
          .from("visit_participants")
          .select("*", { count: "exact", head: true })
          .eq("visit_id", visit.id)
          .eq("status", "confirmed")

        if (count && count >= visit.max_participants) {
          throw new Error("Esta subida ya está completa")
        }
      }

      // Register participant
      const { error: insertError } = await supabase.from("visit_participants").insert({
        visit_id: visit.id,
        user_id: user.id,
        status: "confirmed",
        notes: notes || null,
      })

      if (insertError) throw insertError

      onSuccess()
    } catch (err) {
      setError(err instanceof Error ? err.message : "Error al registrarse")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Inscripción a Subida</DialogTitle>
          <DialogDescription>{visit.title}</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="space-y-4 py-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            <div className="space-y-2">
              <Label htmlFor="notes">Notas o comentarios (opcional)</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Alguna información adicional que quieras compartir"
                disabled={isLoading}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose} disabled={isLoading}>
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Inscribiendo..." : "Confirmar Inscripción"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
