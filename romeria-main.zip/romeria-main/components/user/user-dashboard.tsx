"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { LogOut, Calendar, Mountain } from "lucide-react"
import { createBrowserClient } from "@/lib/supabase/client"
import type { Database } from "@/lib/types/database"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { format } from "date-fns"
import { es } from "date-fns/locale"

type Profile = Database["public"]["Tables"]["profiles"]["Row"]

type VisitParticipant = Database["public"]["Tables"]["visit_participants"]["Row"] & {
  sanctuary_visits?: Database["public"]["Tables"]["sanctuary_visits"]["Row"] | null
}

interface UserDashboardProps {
  profile: Profile
}

const typeLabels: Record<string, string> = {
  walking: "Andando",
  mule: "Mulo",
  horse: "Caballo",
}

export function UserDashboard({ profile }: UserDashboardProps) {
  const [registrations, setRegistrations] = useState<VisitParticipant[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const supabase = createBrowserClient()

  useEffect(() => {
    async function fetchRegistrations() {
      setIsLoading(true)
      const { data } = await supabase
        .from("visit_participants")
        .select("*, sanctuary_visits(*)")
        .eq("user_id", profile.id)
        .order("created_at", { ascending: false })

      if (data) setRegistrations(data as VisitParticipant[])
      setIsLoading(false)
    }

    fetchRegistrations()
  }, [profile.id])

  async function handleLogout() {
    await supabase.auth.signOut()
    router.push("/auth/login")
    router.refresh()
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-foreground">Mi Panel</h1>
          <Button variant="outline" onClick={handleLogout}>
            <LogOut className="w-4 h-4 mr-2" />
            Cerrar Sesión
          </Button>
        </div>
      </header>
      <main className="container mx-auto px-4 py-8">
        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Bienvenido, {profile.full_name}</CardTitle>
              <CardDescription>Aquí puedes gestionar tus inscripciones a las subidas al santuario</CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Mis Inscripciones</CardTitle>
                  <CardDescription>Subidas en las que estás inscrito</CardDescription>
                </div>
                <Button asChild>
                  <Link href="/visitas">
                    <Mountain className="w-4 h-4 mr-2" />
                    Ver Subidas
                  </Link>
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <p className="text-muted-foreground text-center py-8">Cargando inscripciones...</p>
              ) : registrations.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-muted-foreground mb-4">No estás inscrito en ninguna subida</p>
                  <Button asChild>
                    <Link href="/visitas">Ver Subidas Disponibles</Link>
                  </Button>
                </div>
              ) : (
                <div className="space-y-3">
                  {registrations.map((reg) => (
                    <div key={reg.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center gap-3">
                          <h3 className="font-semibold">{reg.sanctuary_visits?.title}</h3>
                          <Badge variant={reg.status === "confirmed" ? "default" : "secondary"}>
                            {reg.status === "confirmed" ? "Confirmado" : "Cancelado"}
                          </Badge>
                          {reg.sanctuary_visits?.type && (
                            <Badge variant="outline">{typeLabels[reg.sanctuary_visits.type]}</Badge>
                          )}
                        </div>
                        {reg.sanctuary_visits?.visit_date && (
                          <p className="text-sm text-muted-foreground mt-1 flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            {format(new Date(reg.sanctuary_visits.visit_date), "d 'de' MMMM 'de' yyyy", {
                              locale: es,
                            })}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
