export type UserRole = "admin" | "carretista" | "caballista" | "user"
export type SubidaType = "andando" | "mulo" | "caballo"
export type PermitStatus = "pending" | "approved" | "rejected"
export type ParticipationStatus = "registered" | "confirmed" | "cancelled"

export interface Profile {
  id: string
  email: string
  full_name: string
  dni?: string
  phone?: string
  role: UserRole
  created_at: string
  updated_at: string
}

export interface CMSPage {
  id: string
  slug: string
  title: string
  content: string
  author_id?: string
  published: boolean
  created_at: string
  updated_at: string
}

export interface CMSPost {
  id: string
  title: string
  slug: string
  content: string
  excerpt?: string
  featured_image?: string
  author_id?: string
  published: boolean
  published_at?: string
  created_at: string
  updated_at: string
}

export interface SanctuaryVisit {
  id: string
  title: string
  description?: string
  visit_date: string
  visit_type: SubidaType
  max_participants?: number
  current_participants: number
  created_by?: string
  created_at: string
  updated_at: string
}

export interface VisitParticipant {
  id: string
  visit_id: string
  user_id: string
  status: ParticipationStatus
  notes?: string
  registered_at: string
}

export interface Vehicle {
  id: string
  owner_id: string
  vehicle_type: string
  license_plate: string
  insurance_policy: string
  insurance_expiry: string
  documentation_url?: string
  created_at: string
  updated_at: string
}

export interface Animal {
  id: string
  owner_id: string
  animal_type: string
  name: string
  breed?: string
  veterinary_doc?: string
  insurance_policy: string
  insurance_expiry: string
  created_at: string
  updated_at: string
}

export interface RomeriaParticipant {
  id: string
  user_id: string
  year: number
  participant_type: UserRole
  full_name: string
  dni: string
  phone: string
  email: string
  address?: string
  vehicle_id?: string
  animal_id?: string
  created_at: string
}

export interface RomeriaPermit {
  id: string
  user_id: string
  year: number
  permit_type: UserRole
  status: PermitStatus
  pdf_url?: string
  signed_pdf_url?: string
  submitted_at: string
  reviewed_at?: string
  reviewed_by?: string
  notes?: string
}
