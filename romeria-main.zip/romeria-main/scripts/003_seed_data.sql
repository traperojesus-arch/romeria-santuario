-- Added author_id column to match schema definition
-- Insert sample CMS pages
INSERT INTO cms_pages (slug, title, content, author_id, published) VALUES
('historia', '# Historia de la Asociación

Nuestra asociación tiene una larga historia vinculada a la tradición de la romería...

## Orígenes

Fundada en 1950, nuestra asociación nació del deseo de mantener vivas las tradiciones...

## Evolución

A lo largo de los años, hemos crecido y nos hemos adaptado a los nuevos tiempos...', NULL, true),

('sobre-nosotros', '# Sobre Nosotros

Somos una asociación dedicada a preservar y promover la tradición de la romería...

## Nuestra Misión

Mantener viva la tradición cultural y religiosa...

## Junta Directiva

- Presidente: [Nombre]
- Vicepresidente: [Nombre]
- Secretario: [Nombre]', NULL, true);

-- Added author_id column to match schema definition
-- Insert sample blog posts
INSERT INTO cms_posts (title, slug, content, excerpt, author_id, published, published_at) VALUES
('Preparativos para la Romería 2026', 'preparativos-romeria-2026', 
'# Preparativos para la Romería 2026

Ya estamos en marcha con los preparativos para la romería de este año...

## Fechas importantes

- Inscripciones: del 1 al 31 de marzo
- Entrega de permisos: hasta el 15 de abril
- Romería: 15 de mayo

## Novedades

Este año incorporamos un nuevo sistema de gestión online...', 
'Conoce todas las novedades y fechas clave para la romería de este año',
NULL,
true, NOW()),

('Normas de Seguridad Actualizadas', 'normas-seguridad-2026',
'# Normas de Seguridad Actualizadas

Se han actualizado las normas de seguridad para garantizar el bienestar de todos...

## Para Carretistas

- Seguro obligatorio de responsabilidad civil
- Revisión técnica del vehículo
- Documentación en regla

## Para Caballistas

- Documentación veterinaria
- Seguro de responsabilidad civil
- Equipamiento adecuado', 
'Nuevas normas de seguridad para carretistas y caballistas',
NULL,
true, NOW());
