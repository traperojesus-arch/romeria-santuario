-- Enable RLS on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE cms_pages ENABLE ROW LEVEL SECURITY;
ALTER TABLE cms_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE sanctuary_visits ENABLE ROW LEVEL SECURITY;
ALTER TABLE visit_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE animals ENABLE ROW LEVEL SECURITY;
ALTER TABLE romeria_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE romeria_permits ENABLE ROW LEVEL SECURITY;
ALTER TABLE permit_participants ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view all profiles" ON profiles FOR SELECT USING (true);
CREATE POLICY "Users can update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Users can insert own profile" ON profiles FOR INSERT WITH CHECK (auth.uid() = id);

-- CMS Pages policies (public read, admin write)
CREATE POLICY "Anyone can view published pages" ON cms_pages FOR SELECT USING (published = true OR auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin'));
CREATE POLICY "Admins can insert pages" ON cms_pages FOR INSERT WITH CHECK (auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin'));
CREATE POLICY "Admins can update pages" ON cms_pages FOR UPDATE USING (auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin'));
CREATE POLICY "Admins can delete pages" ON cms_pages FOR DELETE USING (auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin'));

-- CMS Posts policies (public read, admin write)
CREATE POLICY "Anyone can view published posts" ON cms_posts FOR SELECT USING (published = true OR auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin'));
CREATE POLICY "Admins can insert posts" ON cms_posts FOR INSERT WITH CHECK (auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin'));
CREATE POLICY "Admins can update posts" ON cms_posts FOR UPDATE USING (auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin'));
CREATE POLICY "Admins can delete posts" ON cms_posts FOR DELETE USING (auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin'));

-- Sanctuary visits policies
CREATE POLICY "Anyone can view visits" ON sanctuary_visits FOR SELECT USING (true);
CREATE POLICY "Admins can insert visits" ON sanctuary_visits FOR INSERT WITH CHECK (auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin'));
CREATE POLICY "Admins can update visits" ON sanctuary_visits FOR UPDATE USING (auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin'));
CREATE POLICY "Admins can delete visits" ON sanctuary_visits FOR DELETE USING (auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin'));

-- Visit participants policies
CREATE POLICY "Users can view own participations" ON visit_participants FOR SELECT USING (auth.uid() = user_id OR auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin'));
CREATE POLICY "Users can register for visits" ON visit_participants FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own participations" ON visit_participants FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can cancel own participations" ON visit_participants FOR DELETE USING (auth.uid() = user_id);

-- Vehicles policies
CREATE POLICY "Users can view own vehicles" ON vehicles FOR SELECT USING (auth.uid() = owner_id OR auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin'));
CREATE POLICY "Users can insert own vehicles" ON vehicles FOR INSERT WITH CHECK (auth.uid() = owner_id);
CREATE POLICY "Users can update own vehicles" ON vehicles FOR UPDATE USING (auth.uid() = owner_id);
CREATE POLICY "Users can delete own vehicles" ON vehicles FOR DELETE USING (auth.uid() = owner_id);

-- Animals policies
CREATE POLICY "Users can view own animals" ON animals FOR SELECT USING (auth.uid() = owner_id OR auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin'));
CREATE POLICY "Users can insert own animals" ON animals FOR INSERT WITH CHECK (auth.uid() = owner_id);
CREATE POLICY "Users can update own animals" ON animals FOR UPDATE USING (auth.uid() = owner_id);
CREATE POLICY "Users can delete own animals" ON animals FOR DELETE USING (auth.uid() = owner_id);

-- Romeria participants policies
CREATE POLICY "Users can view own romeria participants" ON romeria_participants FOR SELECT USING (auth.uid() = user_id OR auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin'));
CREATE POLICY "Users can insert own romeria participants" ON romeria_participants FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own romeria participants" ON romeria_participants FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own romeria participants" ON romeria_participants FOR DELETE USING (auth.uid() = user_id);

-- Romeria permits policies
CREATE POLICY "Users can view own permits" ON romeria_permits FOR SELECT USING (auth.uid() = user_id OR auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin'));
CREATE POLICY "Users can insert own permits" ON romeria_permits FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own pending permits" ON romeria_permits FOR UPDATE USING (auth.uid() = user_id AND status = 'pending');
CREATE POLICY "Admins can update any permit" ON romeria_permits FOR UPDATE USING (auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin'));

-- Permit participants policies
CREATE POLICY "Users can view own permit participants" ON permit_participants FOR SELECT USING (
  permit_id IN (SELECT id FROM romeria_permits WHERE user_id = auth.uid()) OR 
  auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin')
);
CREATE POLICY "Users can insert permit participants" ON permit_participants FOR INSERT WITH CHECK (
  permit_id IN (SELECT id FROM romeria_permits WHERE user_id = auth.uid())
);
CREATE POLICY "Users can delete permit participants" ON permit_participants FOR DELETE USING (
  permit_id IN (SELECT id FROM romeria_permits WHERE user_id = auth.uid() AND status = 'pending')
);
