-- Fix schema to match the application code

-- Drop incorrect columns if they exist
ALTER TABLE cms_pages DROP COLUMN IF EXISTS published;
ALTER TABLE cms_posts DROP COLUMN IF EXISTS published;

-- Add correct columns to cms_pages
ALTER TABLE cms_pages ADD COLUMN IF NOT EXISTS is_published BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE cms_pages ADD COLUMN IF NOT EXISTS meta_description TEXT;

-- Add correct columns to cms_posts (blog_posts)
ALTER TABLE IF EXISTS cms_posts RENAME TO blog_posts;

ALTER TABLE blog_posts ADD COLUMN IF NOT EXISTS is_published BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE blog_posts ADD COLUMN IF NOT EXISTS category TEXT NOT NULL DEFAULT 'blog';

-- Fix sanctuary_visits columns
ALTER TABLE sanctuary_visits DROP COLUMN IF EXISTS visit_type;
ALTER TABLE sanctuary_visits DROP COLUMN IF EXISTS current_participants;

ALTER TABLE sanctuary_visits ADD COLUMN IF NOT EXISTS type TEXT NOT NULL DEFAULT 'walking';
ALTER TABLE sanctuary_visits ADD COLUMN IF NOT EXISTS meeting_time TEXT;
ALTER TABLE sanctuary_visits ADD COLUMN IF NOT EXISTS meeting_point TEXT;

-- Fix visit_participants status
ALTER TABLE visit_participants DROP COLUMN IF EXISTS status;
ALTER TABLE visit_participants ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'confirmed';
ALTER TABLE visit_participants DROP COLUMN IF EXISTS registered_at;
ALTER TABLE visit_participants ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ NOT NULL DEFAULT NOW();

-- Fix vehicles table
ALTER TABLE vehicles DROP COLUMN IF EXISTS vehicle_type;
ALTER TABLE vehicles DROP COLUMN IF EXISTS insurance_policy;
ALTER TABLE vehicles DROP COLUMN IF EXISTS insurance_expiry;
ALTER TABLE vehicles DROP COLUMN IF EXISTS documentation_url;

ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS brand TEXT;
ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS model TEXT;
ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS insurance_number TEXT;
ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS insurance_expiry_date DATE;

-- Create saved_participants table
CREATE TABLE IF NOT EXISTS saved_participants (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  dni TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Fix romeria_permits table
ALTER TABLE romeria_permits DROP COLUMN IF EXISTS permit_type;
ALTER TABLE romeria_permits DROP COLUMN IF EXISTS submitted_at;
ALTER TABLE romeria_permits DROP COLUMN IF EXISTS reviewed_at;
ALTER TABLE romeria_permits DROP COLUMN IF EXISTS reviewed_by;

ALTER TABLE romeria_permits ADD COLUMN IF NOT EXISTS vehicle_id UUID REFERENCES vehicles(id);
ALTER TABLE romeria_permits ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ NOT NULL DEFAULT NOW();

-- Recreate permit_participants with correct structure
DROP TABLE IF EXISTS permit_participants CASCADE;

CREATE TABLE permit_participants (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  permit_id UUID REFERENCES romeria_permits(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  dni TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Drop unused tables
DROP TABLE IF EXISTS romeria_participants CASCADE;
DROP TABLE IF EXISTS animals CASCADE;

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_saved_participants_user ON saved_participants(user_id);
CREATE INDEX IF NOT EXISTS idx_permit_participants_permit ON permit_participants(permit_id);
CREATE INDEX IF NOT EXISTS idx_vehicles_owner ON vehicles(owner_id);

-- Add updated_at trigger for saved_participants
CREATE TRIGGER update_saved_participants_updated_at BEFORE UPDATE ON saved_participants
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
