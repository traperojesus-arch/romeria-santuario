-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create enum types
CREATE TYPE user_role AS ENUM ('admin', 'carretista', 'caballista', 'user');
CREATE TYPE subida_type AS ENUM ('andando', 'mulo', 'caballo');
CREATE TYPE permit_status AS ENUM ('pending', 'approved', 'rejected');
CREATE TYPE participation_status AS ENUM ('registered', 'confirmed', 'cancelled');

-- Profiles table (extends auth.users)
CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT NOT NULL,
  dni TEXT,
  phone TEXT,
  role user_role NOT NULL DEFAULT 'user',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- CMS Content tables
CREATE TABLE cms_pages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  author_id UUID REFERENCES profiles(id),
  published BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE cms_posts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  content TEXT NOT NULL,
  excerpt TEXT,
  featured_image TEXT,
  author_id UUID REFERENCES profiles(id),
  published BOOLEAN NOT NULL DEFAULT false,
  published_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Sanctuary visits (subidas programadas)
CREATE TABLE sanctuary_visits (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  description TEXT,
  visit_date DATE NOT NULL,
  visit_type subida_type NOT NULL,
  max_participants INTEGER,
  current_participants INTEGER NOT NULL DEFAULT 0,
  created_by UUID REFERENCES profiles(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Participants in sanctuary visits
CREATE TABLE visit_participants (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  visit_id UUID REFERENCES sanctuary_visits(id) ON DELETE CASCADE,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  status participation_status NOT NULL DEFAULT 'registered',
  notes TEXT,
  registered_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(visit_id, user_id)
);

-- Vehicles (carretas)
CREATE TABLE vehicles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  owner_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  vehicle_type TEXT NOT NULL DEFAULT 'carreta',
  license_plate TEXT NOT NULL,
  insurance_policy TEXT NOT NULL,
  insurance_expiry DATE NOT NULL,
  documentation_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Animals (caballos)
CREATE TABLE animals (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  owner_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  animal_type TEXT NOT NULL DEFAULT 'caballo',
  name TEXT NOT NULL,
  breed TEXT,
  veterinary_doc TEXT,
  insurance_policy TEXT NOT NULL,
  insurance_expiry DATE NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Romería participants (carretistas y caballistas)
CREATE TABLE romeria_participants (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  year INTEGER NOT NULL,
  participant_type user_role NOT NULL CHECK (participant_type IN ('carretista', 'caballista')),
  full_name TEXT NOT NULL,
  dni TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT NOT NULL,
  address TEXT,
  vehicle_id UUID REFERENCES vehicles(id),
  animal_id UUID REFERENCES animals(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, year, participant_type)
);

-- Romería permits
CREATE TABLE romeria_permits (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  year INTEGER NOT NULL,
  permit_type user_role NOT NULL CHECK (permit_type IN ('carretista', 'caballista')),
  status permit_status NOT NULL DEFAULT 'pending',
  pdf_url TEXT,
  signed_pdf_url TEXT,
  submitted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  reviewed_at TIMESTAMPTZ,
  reviewed_by UUID REFERENCES profiles(id),
  notes TEXT,
  UNIQUE(user_id, year, permit_type)
);

-- Permit participants (people in each permit)
CREATE TABLE permit_participants (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  permit_id UUID REFERENCES romeria_permits(id) ON DELETE CASCADE,
  romeria_participant_id UUID REFERENCES romeria_participants(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(permit_id, romeria_participant_id)
);

-- Create indexes
CREATE INDEX idx_cms_pages_slug ON cms_pages(slug);
CREATE INDEX idx_cms_posts_slug ON cms_posts(slug);
CREATE INDEX idx_cms_posts_published ON cms_posts(published, published_at);
CREATE INDEX idx_sanctuary_visits_date ON sanctuary_visits(visit_date);
CREATE INDEX idx_sanctuary_visits_type ON sanctuary_visits(visit_type);
CREATE INDEX idx_visit_participants_visit ON visit_participants(visit_id);
CREATE INDEX idx_visit_participants_user ON visit_participants(user_id);
CREATE INDEX idx_romeria_participants_year ON romeria_participants(year);
CREATE INDEX idx_romeria_permits_year ON romeria_permits(year);
CREATE INDEX idx_romeria_permits_status ON romeria_permits(status);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add triggers for updated_at
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_cms_pages_updated_at BEFORE UPDATE ON cms_pages
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_cms_posts_updated_at BEFORE UPDATE ON cms_posts
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_sanctuary_visits_updated_at BEFORE UPDATE ON sanctuary_visits
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_vehicles_updated_at BEFORE UPDATE ON vehicles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_animals_updated_at BEFORE UPDATE ON animals
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
