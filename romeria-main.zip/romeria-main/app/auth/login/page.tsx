import { LoginForm } from "@/components/auth/login-form"
import { getUser } from "@/lib/auth/auth-utils"
import { redirect } from "next/navigation"

export default async function LoginPage() {
  const user = await getUser()

  if (user) {
    redirect("/dashboard")
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Bienvenido</h1>
          <p className="text-muted-foreground">Accede a tu cuenta para continuar</p>
        </div>
        <LoginForm />
      </div>
    </div>
  )
}
