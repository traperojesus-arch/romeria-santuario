import { requireAuth } from "@/lib/auth/auth-utils"
import { AdminDashboard } from "@/components/admin/admin-dashboard"

export default async function AdminDashboardPage() {
  await requireAuth(["admin"])

  return <AdminDashboard />
}
