import { requireAuth } from "@/lib/auth/auth-utils"
import { VisitsManager } from "@/components/admin/visits-manager"

export default async function AdminVisitsPage() {
  await requireAuth(["admin"])

  return <VisitsManager />
}
