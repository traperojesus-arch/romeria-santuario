import { requireAuth } from "@/lib/auth/auth-utils"
import { ParticipantsManager } from "@/components/admin/participants-manager"
import { notFound } from "next/navigation"

interface ParticipantsPageProps {
  params: Promise<{ id: string }>
}

export default async function ParticipantsPage({ params }: ParticipantsPageProps) {
  await requireAuth(["admin"])
  const { id } = await params

  if (!id) {
    notFound()
  }

  return <ParticipantsManager visitId={id} />
}
