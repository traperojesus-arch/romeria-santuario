import { requireAuth } from "@/lib/auth/auth-utils"
import { CarretistaDashboard } from "@/components/carretista/carretista-dashboard"

export default async function CarretistaDashboardPage() {
  const profile = await requireAuth(["carretista"])

  return <CarretistaDashboard profile={profile} />
}
