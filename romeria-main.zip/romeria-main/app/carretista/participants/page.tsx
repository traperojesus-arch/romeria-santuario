import { requireAuth } from "@/lib/auth/auth-utils"
import { ParticipantsLibrary } from "@/components/carretista/participants-library"

export default async function ParticipantsLibraryPage() {
  const profile = await requireAuth(["carretista", "caballista"])

  return <ParticipantsLibrary profile={profile} />
}
