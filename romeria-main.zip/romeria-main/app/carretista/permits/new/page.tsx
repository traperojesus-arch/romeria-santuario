import { requireAuth } from "@/lib/auth/auth-utils"
import { PermitForm } from "@/components/carretista/permit-form"

export default async function NewPermitPage() {
  const profile = await requireAuth(["carretista"])

  return <PermitForm profile={profile} />
}
