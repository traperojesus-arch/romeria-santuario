import { requireAuth } from "@/lib/auth/auth-utils"
import { redirect } from "next/navigation"

export default async function DashboardPage() {
  const profile = await requireAuth()

  // Redirect based on role
  if (profile.role === "admin") {
    redirect("/admin/dashboard")
  } else if (profile.role === "carretista") {
    redirect("/carretista/dashboard")
  } else if (profile.role === "caballista") {
    redirect("/caballista/dashboard")
  } else {
    redirect("/user/dashboard")
  }
}
