import { requireAuth } from "@/lib/auth/auth-utils"
import { CaballistaDashboard } from "@/components/caballista/caballista-dashboard"

export default async function CaballistaDashboardPage() {
  const profile = await requireAuth(["caballista"])

  return <CaballistaDashboard profile={profile} />
}
