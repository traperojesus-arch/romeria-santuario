import { requireAuth } from "@/lib/auth/auth-utils"
import { PermitForm } from "@/components/carretista/permit-form"

export default async function NewPermitPage() {
  const profile = await requireAuth(["caballista"])

  return <PermitForm profile={profile} />
}
