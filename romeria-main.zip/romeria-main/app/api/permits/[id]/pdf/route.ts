import { createServerClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const supabase = await createServerClient()

    // Get user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "No autorizado" }, { status: 401 })
    }

    // Get permit with participants and vehicle
    const { data: permit, error: permitError } = await supabase
      .from("romeria_permits")
      .select(
        `
        *,
        profiles!romeria_permits_user_id_fkey(full_name, email, phone, dni),
        vehicles(license_plate, brand, model, insurance_number, insurance_expiry_date),
        permit_participants(full_name, dni, phone, email)
      `,
      )
      .eq("id", id)
      .single()

    if (permitError || !permit) {
      return NextResponse.json({ error: "Permiso no encontrado" }, { status: 404 })
    }

    // Check authorization
    if (permit.user_id !== user.id) {
      const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).single()

      if (profile?.role !== "admin") {
        return NextResponse.json({ error: "No autorizado" }, { status: 403 })
      }
    }

    // Generate PDF HTML
    const html = generatePermitHTML(permit)

    // Return HTML that can be printed to PDF
    return new NextResponse(html, {
      headers: {
        "Content-Type": "text/html",
      },
    })
  } catch (error) {
    console.error("[v0] Error generating PDF:", error)
    return NextResponse.json({ error: "Error al generar el PDF" }, { status: 500 })
  }
}

function generatePermitHTML(permit: any): string {
  const profile = permit.profiles
  const vehicle = permit.vehicles
  const participants = permit.permit_participants || []

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Permiso Romería ${permit.year}</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      padding: 40px;
      color: #333;
    }
    .header {
      text-align: center;
      margin-bottom: 40px;
      border-bottom: 3px solid #8B4513;
      padding-bottom: 20px;
    }
    .header h1 {
      color: #8B4513;
      margin: 0;
    }
    .section {
      margin-bottom: 30px;
    }
    .section h2 {
      color: #8B4513;
      border-bottom: 2px solid #DEB887;
      padding-bottom: 5px;
      margin-bottom: 15px;
    }
    .info-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 15px;
      margin-bottom: 20px;
    }
    .info-item {
      padding: 10px;
      background: #f9f9f9;
      border-radius: 5px;
    }
    .info-label {
      font-weight: bold;
      color: #666;
      font-size: 12px;
      margin-bottom: 5px;
    }
    .info-value {
      color: #333;
      font-size: 14px;
    }
    .participants-table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
    }
    .participants-table th {
      background: #8B4513;
      color: white;
      padding: 10px;
      text-align: left;
    }
    .participants-table td {
      padding: 10px;
      border-bottom: 1px solid #ddd;
    }
    .participants-table tr:nth-child(even) {
      background: #f9f9f9;
    }
    .signature-section {
      margin-top: 50px;
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 40px;
    }
    .signature-box {
      border-top: 2px solid #333;
      padding-top: 10px;
      text-align: center;
    }
    .footer {
      margin-top: 50px;
      text-align: center;
      font-size: 12px;
      color: #666;
    }
    @media print {
      body {
        padding: 20px;
      }
    }
  </style>
</head>
<body>
  <div class="header">
    <h1>SOLICITUD DE PERMISO - ROMERÍA ${permit.year}</h1>
    <p>Documento Nº: ${permit.id.substring(0, 8).toUpperCase()}</p>
  </div>

  <div class="section">
    <h2>Datos del Solicitante</h2>
    <div class="info-grid">
      <div class="info-item">
        <div class="info-label">Nombre Completo</div>
        <div class="info-value">${profile?.full_name || "N/A"}</div>
      </div>
      <div class="info-item">
        <div class="info-label">DNI</div>
        <div class="info-value">${profile?.dni || "N/A"}</div>
      </div>
      <div class="info-item">
        <div class="info-label">Teléfono</div>
        <div class="info-value">${profile?.phone || "N/A"}</div>
      </div>
      <div class="info-item">
        <div class="info-label">Email</div>
        <div class="info-value">${profile?.email || "N/A"}</div>
      </div>
    </div>
  </div>

  ${
    vehicle
      ? `
  <div class="section">
    <h2>Datos del Vehículo</h2>
    <div class="info-grid">
      <div class="info-item">
        <div class="info-label">Matrícula</div>
        <div class="info-value">${vehicle.license_plate}</div>
      </div>
      <div class="info-item">
        <div class="info-label">Marca y Modelo</div>
        <div class="info-value">${vehicle.brand || ""} ${vehicle.model || ""}</div>
      </div>
      <div class="info-item">
        <div class="info-label">Seguro</div>
        <div class="info-value">${vehicle.insurance_number || "N/A"}</div>
      </div>
      <div class="info-item">
        <div class="info-label">Vencimiento Seguro</div>
        <div class="info-value">${vehicle.insurance_expiry_date || "N/A"}</div>
      </div>
    </div>
  </div>
  `
      : ""
  }

  ${
    participants.length > 0
      ? `
  <div class="section">
    <h2>Participantes</h2>
    <table class="participants-table">
      <thead>
        <tr>
          <th>Nombre Completo</th>
          <th>DNI</th>
          <th>Teléfono</th>
          <th>Email</th>
        </tr>
      </thead>
      <tbody>
        ${participants
          .map(
            (p: any) => `
          <tr>
            <td>${p.full_name}</td>
            <td>${p.dni}</td>
            <td>${p.phone || "-"}</td>
            <td>${p.email || "-"}</td>
          </tr>
        `,
          )
          .join("")}
      </tbody>
    </table>
  </div>
  `
      : ""
  }

  ${
    permit.notes
      ? `
  <div class="section">
    <h2>Notas Adicionales</h2>
    <div class="info-item">
      <div class="info-value">${permit.notes}</div>
    </div>
  </div>
  `
      : ""
  }

  <div class="signature-section">
    <div class="signature-box">
      <p>Firma del Solicitante</p>
    </div>
    <div class="signature-box">
      <p>Sello de la Organización</p>
    </div>
  </div>

  <div class="footer">
    <p>Este documento es válido únicamente con las firmas correspondientes</p>
    <p>Generado el ${new Date().toLocaleDateString("es-ES")}</p>
  </div>
</body>
</html>
  `
}
