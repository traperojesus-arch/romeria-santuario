import { PublicVisitsCalendar } from "@/components/public/public-visits-calendar"

export default function VisitsPage() {
  return <PublicVisitsCalendar />
}
