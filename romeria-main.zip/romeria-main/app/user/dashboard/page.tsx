import { requireAuth } from "@/lib/auth/auth-utils"
import { UserDashboard } from "@/components/user/user-dashboard"

export default async function UserDashboardPage() {
  const profile = await requireAuth()

  return <UserDashboard profile={profile} />
}
